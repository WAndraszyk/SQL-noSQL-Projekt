prompt --application/shared_components/navigation/lists/navigation_menu
begin
--   Manifest
--     LIST: Navigation Menu
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.7'
,p_default_workspace_id=>9214920906058016
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WITOLD'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(10020047575127940)
,p_name=>'Navigation Menu'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(10176704530128078)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Home'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(10670360999822483)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('Wyszukiwarka specjalist\00F3w')
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-user-md'
,p_security_scheme=>wwv_flow_api.id(10642250957615274)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'2'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(11070522729703170)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Kalendarz Specjalisty'
,p_list_item_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-address-book'
,p_security_scheme=>wwv_flow_api.id(10661487041692112)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'3,4,3,4'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(11162167768872037)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Kalendarz pacjenta'
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-address-book-o'
,p_security_scheme=>wwv_flow_api.id(10642250957615274)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'5,6'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(11179402735043445)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>unistr('Oferta zabieg\00F3w')
,p_list_item_link_target=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-stethoscope'
,p_security_scheme=>wwv_flow_api.id(10661487041692112)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'8,9'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(11241471363908645)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>unistr('Oferta bada\0144')
,p_list_item_link_target=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-syringe'
,p_security_scheme=>wwv_flow_api.id(10661687629695597)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'31'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(11262900486033644)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Twoje laboratorium'
,p_list_item_link_target=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-flask'
,p_security_scheme=>wwv_flow_api.id(10661687629695597)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'33'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(11281423962183665)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Rejestracja laboratorium'
,p_list_item_link_target=>'f?p=&APP_ID.:34:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-clipboard-edit'
,p_security_scheme=>wwv_flow_api.id(10661687629695597)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'34'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(11309060168476151)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Twoja poradnia'
,p_list_item_link_target=>'f?p=&APP_ID.:41:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-hospital-o'
,p_security_scheme=>wwv_flow_api.id(10661487041692112)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'41'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(11322811681567214)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Rejestracja poradni'
,p_list_item_link_target=>'f?p=&APP_ID.:42:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-clipboard-edit'
,p_security_scheme=>wwv_flow_api.id(10661487041692112)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'42'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(11331039364642032)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>unistr('Wyszukiwarka laboratori\00F3w')
,p_list_item_link_target=>'f?p=&APP_ID.:51:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-vial'
,p_security_scheme=>wwv_flow_api.id(10642250957615274)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'51'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(11410198449989189)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'Zlecone badania'
,p_list_item_link_target=>'f?p=&APP_ID.:53:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-vials'
,p_security_scheme=>wwv_flow_api.id(10642250957615274)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'53,54'
);
wwv_flow_api.component_end;
end;
/
