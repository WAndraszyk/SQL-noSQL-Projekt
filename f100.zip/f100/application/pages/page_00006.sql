prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.7'
,p_default_workspace_id=>9214920906058016
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WITOLD'
);
wwv_flow_api.create_page(
 p_id=>6
,p_user_interface_id=>wwv_flow_api.id(10166784291128037)
,p_name=>unistr('Odwo\0142aj wizyt\0119')
,p_alias=>unistr('ODWO\0141AJ-WIZYT\01181')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Odwo\0142aj wizyt\0119')
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(10616259438113138)
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'WITOLD'
,p_last_upd_yyyymmddhh24miss=>'20220112133250'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11151156340872027)
,p_plug_name=>unistr('Odwo\0142aj wizyt\0119')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(10046124160127959)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT TO_CHAR(J.DATA_I_GODZINA, ''DD.MM.YYYY HH24:MI'') as DATA, U.IMIE||'' ''|| U.NAZWISKO AS SPECJALISTA,',
'        W.TYP, Z.NAZWA_ZABIEGU, W.ID',
'FROM JEDNOSTKI_CZASU J JOIN UZYTKOWNICY  U ON J.PESEL_SPECJALISTY = U.PESEL',
'        JOIN WIZYTY W ON J.ID_WIZYTY = W.ID ',
'        LEFT JOIN ZABIEGI_NA_WIZYTACH Z ON W.ID = Z.ID',
'WHERE J.PESEL_PACJENTA = (SELECT PESEL FROM UZYTKOWNICY U2 WHERE UPPER(USERNAME) = :APP_USER)',
'ORDER BY J.DATA_I_GODZINA;'))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11155064773872031)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(10047125082127959)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11155470069872032)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(11155064773872031)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(10142297750128013)
,p_button_image_alt=>'Cofnij'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11157031840872034)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(11155064773872031)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(10142297750128013)
,p_button_image_alt=>unistr('Odwo\0142aj wizyt\0119')
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_execute_validations=>'N'
,p_button_condition=>'P6_DATA'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11151527441872029)
,p_name=>'P6_DATA'
,p_source_data_type=>'VARCHAR2'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(11151156340872027)
,p_item_source_plug_id=>wwv_flow_api.id(11151156340872027)
,p_prompt=>'New'
,p_source=>'DATA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(10139750822128010)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11151981708872030)
,p_name=>'P6_SPECJALISTA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(11151156340872027)
,p_item_source_plug_id=>wwv_flow_api.id(11151156340872027)
,p_prompt=>'Specjalista'
,p_source=>'SPECJALISTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(10139750822128010)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11152375881872030)
,p_name=>'P6_TYP'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(11151156340872027)
,p_item_source_plug_id=>wwv_flow_api.id(11151156340872027)
,p_prompt=>'Typ'
,p_source=>'TYP'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(10141044874128012)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11152726415872030)
,p_name=>'P6_NAZWA_ZABIEGU'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(11151156340872027)
,p_item_source_plug_id=>wwv_flow_api.id(11151156340872027)
,p_prompt=>'Nazwa Zabiegu'
,p_source=>'NAZWA_ZABIEGU'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(10139750822128010)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11153196925872030)
,p_name=>'P6_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(11151156340872027)
,p_item_source_plug_id=>wwv_flow_api.id(11151156340872027)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(11155537148872032)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(11155470069872032)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(11156320074872033)
,p_event_id=>wwv_flow_api.id(11155537148872032)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11158696342872035)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Process form Odwo\0142aj wizyt\0119')
,p_process_sql_clob=>'delete from WIZYTY where ID = :P6_ID;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11159002768872035)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11158283357872034)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(11151156340872027)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Initialize form Odwo\0142aj wizyt\0119')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
