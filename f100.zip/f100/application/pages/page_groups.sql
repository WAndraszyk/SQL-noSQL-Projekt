prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 100
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.7'
,p_default_workspace_id=>9214920906058016
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WITOLD'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(10169953996128051)
,p_group_name=>'Administration'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(10616587702118762)
,p_group_name=>'Laborant'
,p_group_desc=>unistr('Strony dost\0119pne dla pracownik\00F3w dlaboratori\00F3w')
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(10616259438113138)
,p_group_name=>'Pacjent'
,p_group_desc=>unistr('Strony dost\0119pne dla pacjent\00F3w')
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(10616472087117292)
,p_group_name=>'Specjalista'
,p_group_desc=>unistr('Strony dost\0119pne dla specjalist\00F3w')
);
wwv_flow_api.component_end;
end;
/
