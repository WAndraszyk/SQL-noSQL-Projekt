prompt --application/pages/page_00033
begin
--   Manifest
--     PAGE: 00033
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.7'
,p_default_workspace_id=>9214920906058016
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WITOLD'
);
wwv_flow_api.create_page(
 p_id=>33
,p_user_interface_id=>wwv_flow_api.id(10166784291128037)
,p_name=>'Twoje laboratorium'
,p_alias=>'TWOJE-LABORATORIUM'
,p_step_title=>'Twoje laboratorium'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'WITOLD'
,p_last_upd_yyyymmddhh24miss=>'20220113151310'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11190162572650038)
,p_plug_name=>'Zmiana laboratorium'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(10077123838127975)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'LABORANCI'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(11263305731033645)
,p_name=>'Twoje laboratorium'
,p_template=>wwv_flow_api.id(10077123838127975)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nazwa, miasto, adres, telefon from laboratoria ',
'where ID =',
'(select ID_LABORATORIUM',
'from laboranci l',
'where l.PESEL = (SELECT u.PESEL FROM UZYTKOWNICY u WHERE UPPER(USERNAME) = :APP_USER));'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(10100875984127987)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>unistr('Nie wybra\0142e\015B \017Cadnego laboratorium.')
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(11263783471033647)
,p_query_column_id=>1
,p_column_alias=>'NAZWA'
,p_column_display_sequence=>10
,p_column_heading=>'Nazwa'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(11264147764033648)
,p_query_column_id=>2
,p_column_alias=>'MIASTO'
,p_column_display_sequence=>20
,p_column_heading=>'Miasto'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(11264593113033648)
,p_query_column_id=>3
,p_column_alias=>'ADRES'
,p_column_display_sequence=>30
,p_column_heading=>'Adres'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(11264955376033648)
,p_query_column_id=>4
,p_column_alias=>'TELEFON'
,p_column_display_sequence=>40
,p_column_heading=>'Telefon'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(11275173279110506)
,p_name=>'Zlecone badania'
,p_template=>wwv_flow_api.id(10077123838127975)
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,NAZWA_BADANIA,',
'       IMIE||'' ''|| NAZWISKO as ZLECENIODAWCA',
'from ZLECONE_BADANIA',
'join UZYTKOWNICY on PESEL_PACJENTA = PESEL',
'where ID_LABORATORIUM =',
'(select ID_LABORATORIUM',
'from laboranci l',
'where l.PESEL = (SELECT u.PESEL FROM UZYTKOWNICY u WHERE UPPER(USERNAME) = :APP_USER));;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(10100875984127987)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(11516168272128205)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>50
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(11275499884110509)
,p_query_column_id=>2
,p_column_alias=>'NAZWA_BADANIA'
,p_column_display_sequence=>30
,p_column_heading=>'Nazwa Badania'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(11275596676110510)
,p_query_column_id=>3
,p_column_alias=>'ZLECENIODAWCA'
,p_column_display_sequence=>40
,p_column_heading=>'Zleceniodawca'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11190556166650042)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(11190162572650038)
,p_button_name=>'WYBIERZ'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(10142297750128013)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Wybierz'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11190384750650040)
,p_name=>'P33_PESEL'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(11190162572650038)
,p_item_source_plug_id=>wwv_flow_api.id(11190162572650038)
,p_source=>'PESEL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11190416203650041)
,p_name=>'LABORATORIUM'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(11190162572650038)
,p_item_source_plug_id=>wwv_flow_api.id(11190162572650038)
,p_prompt=>'Moje laboratorium'
,p_source=>'ID_LABORATORIUM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select nazwa, id from laboratoria;'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(10139750822128010)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11190690444650043)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Zmiana laboratorium'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'UPDATE LABORANCI',
'SET ID_LABORATORIUM = :LABORATORIUM',
'WHERE PESEL = (SELECT u.PESEL FROM UZYTKOWNICY u WHERE UPPER(USERNAME) = :APP_USER);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(11190556166650042)
,p_process_when=>'LABORATORIUM'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11190248616650039)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(11190162572650038)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Twoje laboratorium'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
