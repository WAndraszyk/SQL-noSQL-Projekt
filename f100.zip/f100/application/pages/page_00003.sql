prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.7'
,p_default_workspace_id=>9214920906058016
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WITOLD'
);
wwv_flow_api.create_page(
 p_id=>3
,p_user_interface_id=>wwv_flow_api.id(10166784291128037)
,p_name=>'Kalendarz specjalisty'
,p_alias=>'KALENDARZ-SPECJALISTY'
,p_step_title=>'Kalendarz specjalisty'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(10616472087117292)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(10661487041692112)
,p_protection_level=>'C'
,p_last_updated_by=>'WITOLD'
,p_last_upd_yyyymmddhh24miss=>'20220112171050'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11139856703718633)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(10075232195127974)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT TO_CHAR(J.DATA_I_GODZINA, ''DD.MM.YYYY HH24:MI'') as DATA, U.IMIE, U.NAZWISKO,',
'        W.TYP, Z.NAZWA_ZABIEGU, W.ID',
'FROM JEDNOSTKI_CZASU J JOIN UZYTKOWNICY  U ON J.PESEL_PACJENTA = U.PESEL',
'        JOIN WIZYTY W ON J.ID_WIZYTY = W.ID ',
'        LEFT JOIN ZABIEGI_NA_WIZYTACH Z ON W.ID = Z.ID',
'WHERE J.PESEL_SPECJALISTY = (SELECT PESEL FROM UZYTKOWNICY U2 WHERE UPPER(USERNAME) = :APP_USER)',
'ORDER BY J.DATA_I_GODZINA;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Report 1'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(11140234318718633)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_actions_menu=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_detail_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:RP:P4_DATA:\#DATA#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'WITOLD'
,p_internal_uid=>11140234318718633
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11140386418718633)
,p_db_column_name=>'DATA'
,p_display_order=>0
,p_column_identifier=>'A'
,p_column_label=>'Data'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11140741495718634)
,p_db_column_name=>'IMIE'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Imie'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11141101774718634)
,p_db_column_name=>'NAZWISKO'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Nazwisko'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11141556478718636)
,p_db_column_name=>'TYP'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Typ'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11141922462718637)
,p_db_column_name=>'NAZWA_ZABIEGU'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Nazwa Zabiegu'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11142380831718637)
,p_db_column_name=>'ID'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(11145557853730014)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'111456'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DATA:IMIE:NAZWISKO:TYP:NAZWA_ZABIEGU:ID'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11188138171650018)
,p_plug_name=>'Wygeneruj nowy kalendarz'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(10077123838127975)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>unistr('UWAGA! WYGENEROWANIE NOWEGO KALENDARZA SPOWODUJE USUNI\0118CIE OBECNEGO! DANE O WIZYTACH ZOSTAN\0104 UTRACONE!')
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11189065821650027)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(11188138171650018)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(10142297750128013)
,p_button_image_alt=>'Wygeneruj'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11188222846650019)
,p_name=>'START_HOUR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(11188138171650018)
,p_prompt=>unistr('Godzina rozpocz\0119cia')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:6;6,7;7,8;8,9;9,10;10,11;11,12;12,13;13,14;14,15;15,16;16,17;17,18;18,19;19,20;20'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(10139750822128010)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11188356970650020)
,p_name=>'START_MINUTE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(11188138171650018)
,p_prompt=>unistr('Minuta rozpocz\0119cia')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:0;0,15;15,30;30,45;45'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(10139750822128010)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11188671717650023)
,p_name=>'KONSULTACJA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(11188138171650018)
,p_prompt=>'Czas trwania konsultacji'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:15;15,30;30,45;45,60;60'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(10139750822128010)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11188702103650024)
,p_name=>'END_HOUR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(11188138171650018)
,p_prompt=>unistr('Godzina zako\0144czenia')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:6;6,7;7,8;8,9;9,10;10,11;11,12;12,13;13,14;14,15;15,16;16,17;17,18;18,19;19,20;20'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(10139750822128010)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11188988013650026)
,p_name=>'END_MINUTE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(11188138171650018)
,p_prompt=>unistr('Minuta zako\0144czenia')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:0;0,15;15,30;30,45;45'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(10139750822128010)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(11143309400718650)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(11139856703718633)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(11143838367718650)
,p_event_id=>wwv_flow_api.id(11143309400718650)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(11139856703718633)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11189132907650028)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Wygeneruj nowy kalendarz'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    vPesel NUMBER(11);',
'begin',
'    SELECT PESEL INTO vPesel FROM UZYTKOWNICY WHERE UPPER(USERNAME)=:APP_USER;',
'    GENERATE_CALENDAR(:START_HOUR, :START_MINUTE, :END_HOUR, :END_MINUTE, :KONSULTACJA, vPesel);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(11189065821650027)
);
wwv_flow_api.component_end;
end;
/
