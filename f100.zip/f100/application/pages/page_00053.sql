prompt --application/pages/page_00053
begin
--   Manifest
--     PAGE: 00053
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.7'
,p_default_workspace_id=>9214920906058016
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WITOLD'
);
wwv_flow_api.create_page(
 p_id=>53
,p_user_interface_id=>wwv_flow_api.id(10166784291128037)
,p_name=>'Zlecone badania'
,p_alias=>'ZLECONE-BADANIA'
,p_step_title=>'Zlecone badania'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(10616259438113138)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'WITOLD'
,p_last_upd_yyyymmddhh24miss=>'20220113150112'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11408414865989188)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(10075232195127974)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT Z.ID as NUMER_BADANIA, Z.NAZWA_BADANIA, L.NAZWA as NAZWA_LABORATORIUM',
'FROM ZLECONE_BADANIA Z JOIN LABORATORIA L ON Z.ID_LABORATORIUM = L.ID  ',
'WHERE Z.PESEL_PACJENTA = (SELECT PESEL FROM UZYTKOWNICY WHERE UPPER(USERNAME) = :APP_USER);'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Report 1'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(11408827512989188)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_actions_menu=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_detail_link=>'f?p=&APP_ID.:54:&SESSION.::&DEBUG.:RP:P54_NUMER_BADANIA:\#NUMER_BADANIA#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'WITOLD'
,p_internal_uid=>11408827512989188
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11408915745989188)
,p_db_column_name=>'NUMER_BADANIA'
,p_display_order=>0
,p_column_identifier=>'A'
,p_column_label=>'Numer Badania'
,p_column_type=>'NUMBER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11409308371989189)
,p_db_column_name=>'NAZWA_BADANIA'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Nazwa Badania'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11409743053989189)
,p_db_column_name=>'NAZWA_LABORATORIUM'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Nazwa Laboratorium'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(11412950786993043)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'114130'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NUMER_BADANIA:NAZWA_BADANIA:NAZWA_LABORATORIUM'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(11410803648989190)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(11408414865989188)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(11411374653989190)
,p_event_id=>wwv_flow_api.id(11410803648989190)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(11408414865989188)
);
wwv_flow_api.component_end;
end;
/
