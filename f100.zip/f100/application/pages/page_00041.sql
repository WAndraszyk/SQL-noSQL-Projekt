prompt --application/pages/page_00041
begin
--   Manifest
--     PAGE: 00041
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.7'
,p_default_workspace_id=>9214920906058016
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WITOLD'
);
wwv_flow_api.create_page(
 p_id=>41
,p_user_interface_id=>wwv_flow_api.id(10166784291128037)
,p_name=>'Twoja poradnia'
,p_alias=>'TWOJA-PORADNIA'
,p_step_title=>'Twoja poradnia'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'WITOLD'
,p_last_upd_yyyymmddhh24miss=>'20220112204950'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(22498869928126186)
,p_plug_name=>'Zmiana poradni'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(10077123838127975)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'SPECJALISCI'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(22572013086509793)
,p_name=>'Twoja poradnia'
,p_template=>wwv_flow_api.id(10077123838127975)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NAZWA, TYP, MIASTO, ADRES, TELEFON from poradnie ',
'where ID =',
'(select ID_PORADNI',
'from specjalisci s',
'where s.PESEL = (SELECT u.PESEL FROM UZYTKOWNICY u WHERE UPPER(USERNAME) = :APP_USER));'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(10100875984127987)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>unistr('Nie wybra\0142e\015B \017Cadnej poradni.')
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(11309725901476153)
,p_query_column_id=>1
,p_column_alias=>'NAZWA'
,p_column_display_sequence=>10
,p_column_heading=>'Nazwa'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(11275626000110511)
,p_query_column_id=>2
,p_column_alias=>'TYP'
,p_column_display_sequence=>50
,p_column_heading=>'Typ'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(11310148813476154)
,p_query_column_id=>3
,p_column_alias=>'MIASTO'
,p_column_display_sequence=>20
,p_column_heading=>'Miasto'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(11310570098476154)
,p_query_column_id=>4
,p_column_alias=>'ADRES'
,p_column_display_sequence=>30
,p_column_heading=>'Adres'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(11310931069476154)
,p_query_column_id=>5
,p_column_alias=>'TELEFON'
,p_column_display_sequence=>40
,p_column_heading=>'Telefon'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11311678180476156)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(22498869928126186)
,p_button_name=>'WYBIERZ'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(10142297750128013)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Wybierz'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11276328708110518)
,p_name=>'MOJA_PORADNIA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(22498869928126186)
,p_prompt=>'Moja poradnia'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select nazwa, id from poradnie;'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(10139750822128010)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11312043420476156)
,p_name=>'P41_PESEL'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(22572013086509793)
,p_item_source_plug_id=>wwv_flow_api.id(22498869928126186)
,p_source=>'PESEL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11315354418476160)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Zmiana laboratorium'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'UPDATE SPECJALISCI',
'SET ID_PORADNI = :MOJA_PORADNIA',
'WHERE PESEL = (SELECT u.PESEL FROM UZYTKOWNICY u WHERE UPPER(USERNAME) = :APP_USER);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(11311678180476156)
,p_process_when=>'MOJA_PORADNIA'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_security_scheme=>wwv_flow_api.id(10661487041692112)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11313410601476157)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(22498869928126186)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Twoje laboratorium'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
