prompt --application/pages/page_00031
begin
--   Manifest
--     PAGE: 00031
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.7'
,p_default_workspace_id=>9214920906058016
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WITOLD'
);
wwv_flow_api.create_page(
 p_id=>31
,p_user_interface_id=>wwv_flow_api.id(10166784291128037)
,p_name=>unistr('Oferta bada\0144')
,p_alias=>unistr('OFERTA-BADA\0143')
,p_step_title=>unistr('Oferta bada\0144')
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(10616472087117292)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(10661687629695597)
,p_protection_level=>'C'
,p_last_updated_by=>'WITOLD'
,p_last_upd_yyyymmddhh24miss=>'20220113152020'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(22418901532952083)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(10075232195127974)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NAZWA_BADANIA, CENA from WYKONYWANE_BADANIA ',
'where ID_LABORATORIUM =',
'(select ID_LABORATORIUM',
'from laboranci l',
'where l.PESEL = (SELECT u.PESEL FROM UZYTKOWNICY u WHERE UPPER(USERNAME) = :APP_USER));'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>'Report 1'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(22419282439952083)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:RP,:P32_NAZWA_BADANIA:\#NAZWA_BADANIA#\#NAZWA_ZABIEGU#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'WITOLD'
,p_internal_uid=>22419282439952083
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11189754327650034)
,p_db_column_name=>'NAZWA_BADANIA'
,p_display_order=>20
,p_column_identifier=>'E'
,p_column_label=>'Nazwa Badania'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11246515653908669)
,p_db_column_name=>'CENA'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>unistr('Cena z\0142')
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(22423152325980119)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'111821'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CENA:NAZWA_BADANIA'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(22427602050558641)
,p_name=>unistr('Baza bada\0144')
,p_template=>wwv_flow_api.id(10077123838127975)
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'TABLE'
,p_query_table=>'BADANIA'
,p_include_rowid_column=>false
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(10100875984127987)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(11242143509908652)
,p_query_column_id=>1
,p_column_alias=>'NAZWA'
,p_column_display_sequence=>10
,p_column_heading=>'Nazwa'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(11189664111650033)
,p_query_column_id=>2
,p_column_alias=>'TYP'
,p_column_display_sequence=>30
,p_column_heading=>'Typ'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(11242519386908652)
,p_query_column_id=>3
,p_column_alias=>'OPIS'
,p_column_display_sequence=>20
,p_column_heading=>'Opis'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(22427692646558642)
,p_plug_name=>'Zdefiniuj nowe badanie'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(10077123838127975)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'BADANIA'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11243255334908660)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(22427692646558642)
,p_button_name=>'NOWE_BADANIE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(10142297750128013)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Dodaj'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11247694942908676)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(22418901532952083)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(10142297750128013)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Dodaj badanie'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:32::'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11189573302650032)
,p_name=>'P31_TYP'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(22427692646558642)
,p_item_source_plug_id=>wwv_flow_api.id(22427692646558642)
,p_prompt=>'Typ'
,p_source=>'TYP'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>unistr('STATIC:krwi;krwi,moczu;moczu,ka\0142u;kalu,wymaz;wymaz')
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(10139750822128010)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11243686548908661)
,p_name=>'P31_NAZWA'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(22427692646558642)
,p_item_source_plug_id=>wwv_flow_api.id(22427692646558642)
,p_prompt=>'Nazwa'
,p_source=>'NAZWA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_field_template=>wwv_flow_api.id(10139750822128010)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11244069467908662)
,p_name=>'P31_OPIS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(22427692646558642)
,p_item_source_plug_id=>wwv_flow_api.id(22427692646558642)
,p_prompt=>'Opis'
,p_source=>'OPIS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>200
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(10139750822128010)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(11516071747128204)
,p_validation_name=>'Nazwa'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from badania',
'where nazwa = :P31_NAZWA;'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>unistr('Badanie o takiej nazwie ju\017C istnieje!')
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(11248442854908683)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(22418901532952083)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(11248969320908685)
,p_event_id=>wwv_flow_api.id(11248442854908683)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(22418901532952083)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11248041017908682)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>'insert into badania values(:P31_NAZWA, :P31_TYP,:P31_OPIS);'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11245058371908664)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(22427692646558642)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Initialize form Oferta zabieg\00F3w')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
