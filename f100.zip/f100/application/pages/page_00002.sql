prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.7'
,p_default_workspace_id=>9214920906058016
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WITOLD'
);
wwv_flow_api.create_page(
 p_id=>2
,p_user_interface_id=>wwv_flow_api.id(10166784291128037)
,p_name=>unistr('Wyszukiwarka specjalist\00F3w')
,p_alias=>unistr('WYSZUKIWARKA-SPECJALIST\00D3W')
,p_step_title=>unistr('Wyszukiwarka specjalist\00F3w')
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(10616259438113138)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(10642250957615274)
,p_last_updated_by=>'WITOLD'
,p_last_upd_yyyymmddhh24miss=>'20220112132414'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10670707050822485)
,p_plug_name=>unistr('Wyszukiwarka specjalist\00F3w')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(10075232195127974)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select s.pesel, imie, nazwisko, LOWER(specjalizacja) as specjalizacja',
'from UZYTKOWNICY U join SPECJALISCI S on U.PESEL = S.PESEL;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>unistr('Wyszukiwarka specjalist\00F3w')
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(10670825612822485)
,p_name=>unistr('Wyszukiwarka specjalist\00F3w')
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_actions_menu=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_owner=>'WITOLD'
,p_internal_uid=>10670825612822485
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10671245338822488)
,p_db_column_name=>'PESEL'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Pesel'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10671654735822488)
,p_db_column_name=>'IMIE'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Imie'
,p_column_link=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.::PESEL:#PESEL#'
,p_column_linktext=>'#IMIE#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10672082794822489)
,p_db_column_name=>'NAZWISKO'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Nazwisko'
,p_column_link=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.::PESEL:#PESEL#'
,p_column_linktext=>'#NAZWISKO#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10672431596822489)
,p_db_column_name=>'SPECJALIZACJA'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Specjalizacja'
,p_column_link=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.::PESEL:#PESEL#'
,p_column_linktext=>'#SPECJALIZACJA#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(10674071413832233)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'106741'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PESEL:IMIE:NAZWISKO:SPECJALIZACJA'
);
wwv_flow_api.component_end;
end;
/
