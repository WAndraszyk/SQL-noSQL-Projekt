prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.7'
,p_default_workspace_id=>9214920906058016
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WITOLD'
);
wwv_flow_api.create_page(
 p_id=>5
,p_user_interface_id=>wwv_flow_api.id(10166784291128037)
,p_name=>'Kalendarz pacjenta'
,p_alias=>'KALENDARZ-PACJENTA'
,p_step_title=>'Kalendarz pacjenta'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(10616259438113138)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'WITOLD'
,p_last_upd_yyyymmddhh24miss=>'20220112132356'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11159691879872035)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(10075232195127974)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT TO_CHAR(J.DATA_I_GODZINA, ''DD.MM.YYYY HH24:MI'') as DATA, U.IMIE||'' ''|| U.NAZWISKO AS SPECJALISTA,',
'        W.TYP, Z.NAZWA_ZABIEGU, W.ID',
'FROM JEDNOSTKI_CZASU J JOIN UZYTKOWNICY  U ON J.PESEL_SPECJALISTY = U.PESEL',
'        JOIN WIZYTY W ON J.ID_WIZYTY = W.ID ',
'        LEFT JOIN ZABIEGI_NA_WIZYTACH Z ON W.ID = Z.ID',
'WHERE J.PESEL_PACJENTA = (SELECT PESEL FROM UZYTKOWNICY U2 WHERE UPPER(USERNAME) = :APP_USER)',
'ORDER BY J.DATA_I_GODZINA;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Report 1'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(11160021470872035)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_actions_menu=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_detail_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:RP:P6_DATA:\#DATA#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'WITOLD'
,p_internal_uid=>11160021470872035
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11160123038872036)
,p_db_column_name=>'DATA'
,p_display_order=>0
,p_column_identifier=>'A'
,p_column_label=>'Data'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11160513154872036)
,p_db_column_name=>'SPECJALISTA'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Specjalista'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11160992885872036)
,p_db_column_name=>'TYP'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Typ'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11161350048872037)
,p_db_column_name=>'NAZWA_ZABIEGU'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Nazwa Zabiegu'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11161753660872037)
,p_db_column_name=>'ID'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(11164747313876865)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'111648'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DATA:SPECJALISTA:TYP:NAZWA_ZABIEGU:ID'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(11162833024872040)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(11159691879872035)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(11163309734872040)
,p_event_id=>wwv_flow_api.id(11162833024872040)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(11159691879872035)
);
wwv_flow_api.component_end;
end;
/
