prompt --application/pages/page_00051
begin
--   Manifest
--     PAGE: 00051
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.7'
,p_default_workspace_id=>9214920906058016
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WITOLD'
);
wwv_flow_api.create_page(
 p_id=>51
,p_user_interface_id=>wwv_flow_api.id(10166784291128037)
,p_name=>unistr('Wyszukiwarka laboratori\00F3w')
,p_alias=>unistr('WYSZUKIWARKA-LABORATORI\00D3W')
,p_step_title=>unistr('Wyszukiwarka laboratori\00F3w')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'WITOLD'
,p_last_upd_yyyymmddhh24miss=>'20220112211055'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11331495090642033)
,p_plug_name=>unistr('Wyszukiwarka laboratori\00F3w')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(10075232195127974)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_plug_source=>'select '
,p_query_table=>'LABORATORIA'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>unistr('Wyszukiwarka laboratori\00F3w')
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(11331530673642033)
,p_name=>unistr('Wyszukiwarka laboratori\00F3w')
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_actions_menu=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_owner=>'WITOLD'
,p_internal_uid=>11331530673642033
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11331911090642034)
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11332324440642035)
,p_db_column_name=>'NAZWA'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Nazwa'
,p_column_link=>'f?p=&APP_ID.:52:&SESSION.::&DEBUG.::ID:#ID#'
,p_column_linktext=>'#NAZWA#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11332726633642035)
,p_db_column_name=>'MIASTO'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Miasto'
,p_column_link=>'f?p=&APP_ID.:52:&SESSION.::&DEBUG.::ID:#ID#'
,p_column_linktext=>'#MIASTO#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11333125337642036)
,p_db_column_name=>'ADRES'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Adres'
,p_column_link=>'f?p=&APP_ID.:52:&SESSION.::&DEBUG.::ID:#ID#'
,p_column_linktext=>'#ADRES#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11333596890642036)
,p_db_column_name=>'TELEFON'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Telefon'
,p_column_link=>'f?p=&APP_ID.:52:&SESSION.::&DEBUG.::ID:#ID#'
,p_column_linktext=>'#TELEFON#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(11334194486643747)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'113342'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:NAZWA:MIASTO:ADRES:TELEFON'
);
wwv_flow_api.component_end;
end;
/
