prompt --application/pages/page_00042
begin
--   Manifest
--     PAGE: 00042
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.7'
,p_default_workspace_id=>9214920906058016
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WITOLD'
);
wwv_flow_api.create_page(
 p_id=>42
,p_user_interface_id=>wwv_flow_api.id(10166784291128037)
,p_name=>'Rejestracja poradni'
,p_alias=>'REJESTRACJA-PORADNI'
,p_step_title=>'Rejestracja poradni'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(10616587702118762)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'WITOLD'
,p_last_upd_yyyymmddhh24miss=>'20220113150738'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(33798781436412637)
,p_plug_name=>unistr('Zarejestruj now\0105 poradni\0119')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(10077123838127975)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'PORADNIE'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11323528846567217)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(33798781436412637)
,p_button_name=>'ZAREJESTRUJ'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(10142297750128013)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Zarejestruj'
,p_button_position=>'REGION_TEMPLATE_CREATE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11276445406110519)
,p_name=>'P42_TYP'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(33798781436412637)
,p_item_source_plug_id=>wwv_flow_api.id(33798781436412637)
,p_prompt=>'Typ'
,p_source=>'TYP'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_field_template=>wwv_flow_api.id(10139750822128010)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11323912670567218)
,p_name=>'P42_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(33798781436412637)
,p_item_source_plug_id=>wwv_flow_api.id(33798781436412637)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11324350861567218)
,p_name=>'P42_NAZWA'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(33798781436412637)
,p_item_source_plug_id=>wwv_flow_api.id(33798781436412637)
,p_prompt=>'Nazwa'
,p_source=>'NAZWA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_field_template=>wwv_flow_api.id(10139750822128010)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11324723819567219)
,p_name=>'P42_MIASTO'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(33798781436412637)
,p_item_source_plug_id=>wwv_flow_api.id(33798781436412637)
,p_prompt=>'Miasto'
,p_source=>'MIASTO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_field_template=>wwv_flow_api.id(10139750822128010)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11325158638567219)
,p_name=>'P42_ADRES'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(33798781436412637)
,p_item_source_plug_id=>wwv_flow_api.id(33798781436412637)
,p_prompt=>'Adres'
,p_source=>'ADRES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>50
,p_field_template=>wwv_flow_api.id(10139750822128010)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11325545086567219)
,p_name=>'P42_TELEFON'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(33798781436412637)
,p_item_source_plug_id=>wwv_flow_api.id(33798781436412637)
,p_prompt=>'Telefon'
,p_source=>'TELEFON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>12
,p_field_template=>wwv_flow_api.id(10139750822128010)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(11327599721567220)
,p_validation_name=>'Nazwa'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 1',
'FROM poradnie',
'WHERE nazwa = :P42_NAZWA;'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>unistr('Poradnia o takiej nazwie ju\017C istnieje w bazie;')
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(11515874479128202)
,p_validation_name=>'Telefon'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 1',
'FROM poradnie',
'WHERE telefon = :P42_TELEFON;'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>unistr('Poradnia o takim numerze telefonu ju\017C istnieje!')
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(11515954830128203)
,p_validation_name=>'Adres'
,p_validation_sequence=>30
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 1',
'FROM poradnie',
'WHERE adres = :P42_ADRES;'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>unistr('Poradnia o takim adresie ju\017C istnieje!')
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11327876573567221)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Nowa poradnia'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'insert into poradnie ',
'values(NULL, :P42_TYP, :P42_NAZWA, :P42_MIASTO, :P42_ADRES, :P42_TELEFON);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(11323528846567217)
);
wwv_flow_api.component_end;
end;
/
